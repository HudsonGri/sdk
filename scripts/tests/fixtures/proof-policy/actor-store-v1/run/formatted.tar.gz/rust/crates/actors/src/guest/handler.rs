//! Durable record handlers shared by native packages and guest execution adapters.
use super::{Checkpoint, CodecIdentity, GuestEvent, GuestFuture};
use crate::{addressing::ActorReference, domain};
use acyclic_stream::{CommitCondition, StreamPath};
use bytes::Bytes;

/// Immutable deployment metadata; resource selection is explicit, never inherited.
pub struct Manifest {
    /// Canonical artifact digest admitted by the deployment service.
    pub code: domain::CodeSha256,
    /// Codec written by this artifact.
    pub codec: CodecIdentity,
    /// Canonical subscription declarations, including their initial cursors.
    pub subscriptions: Vec<domain::SubscriptionSpec>,
    /// Canonical explicit resource bindings.
    pub bindings: Vec<domain::Binding>,
    /// Canonical execution and checkpoint bounds.
    pub limits: domain::ActorLimits,
}

/// Durable identity of a delivery, independent of physical handler attempts.
#[derive(Clone, Debug, PartialEq, Eq)]
pub enum Trigger {
    /// Consume exactly the next record of one declared subscription.
    Record {
        /// Manifest subscription identity.
        subscription: String,
        /// Zero-based source record sequence.
        sequence: u64,
    },
    /// Consume only the currently retained alarm generation.
    Alarm {
        /// Generation captured when this wake was queued.
        generation: u64,
        /// Clock observation admitted by the host, in Unix milliseconds.
        now_unix_ms: u64,
    },
}

/// Invocation-scoped host input; it contains no deployment credentials.
pub struct Delivery {
    /// Complete account/namespace/id address.
    pub actor: ActorReference,
    /// Placement fence admitted by the host.
    pub epoch: u64,
    /// Stable logical delivery identity.
    pub trigger: Trigger,
    /// The existing portable guest event ABI.
    pub event: GuestEvent,
}

/// Change to the actor's sole durable alarm, committed with its checkpoint.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum AlarmChange {
    /// Preserve the pending alarm; a delivered alarm is consumed.
    Keep,
    /// Replace the alarm with a strictly positive absolute deadline.
    Set {
        /// Unix milliseconds.
        deadline_unix_ms: u64,
    },
    /// Clear the alarm and invalidate any previously queued wake.
    Clear,
}

/// An outbox append published in the same transaction as consumed input.
pub struct Effect {
    /// Exact admitted destination cut, retained unchanged for request replay.
    pub condition: CommitCondition,
    /// Opaque bytes; no external action executes before the checkpoint commit.
    pub value: Bytes,
}

impl Effect {
    /// Explicitly bound destination; the condition cannot name another stream.
    pub fn stream(&self) -> &StreamPath {
        match &self.condition {
            CommitCondition::Head { path, .. }
            | CommitCondition::Tail { path, .. }
            | CommitCondition::Absent { path } => path,
        }
    }
}

/// One indivisible logical result. Physical execution may repeat after a crash.
pub struct Transition {
    /// Artifact-owned state encoded with the declared codec.
    pub checkpoint: Checkpoint,
    /// Alarm mutation, including clear-generation fencing.
    pub alarm: AlarmChange,
    /// Committed effects, never an independent best-effort dispatch path.
    pub effects: Vec<Effect>,
}

/// The sole durable record-handler contract, independent of host and OS.
pub trait Handler: Send + Sync {
    /// The package's immutable code, codec, subscriptions and bindings.
    fn manifest(&self) -> &Manifest;
    /// Compute a transition without independently acknowledging input or effects.
    fn on_record<'a>(
        &'a self,
        delivery: Delivery,
        checkpoint: Option<&'a Checkpoint>,
    ) -> GuestFuture<'a, Transition>;
}
